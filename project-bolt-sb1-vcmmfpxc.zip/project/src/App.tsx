import Header from "./components/Header";
import Hero from "./components/sections/Hero";
import About from "./components/sections/About";
import Platform from "./components/sections/Platform";
import Capabilities from "./components/sections/Capabilities";
import WhyUs from "./components/sections/WhyUs";
import Testimonials from "./components/sections/Testimonials";
import FAQ from "./components/sections/FAQ";
import Contact from "./components/sections/Contact";
import Footer from "./components/Footer";
import CookieConsent from "./components/CookieConsent";

export default function App() {
  return (
    <div className="min-h-screen" style={{ backgroundColor: "var(--color-bg)", color: "var(--color-text)" }}>
      <Header />
      <main>
        <Hero />
        <div className="section-divider" />
        <About />
        <div className="section-divider" />
        <Platform />
        <div className="section-divider" />
        <Capabilities />
        <div className="section-divider" />
        <WhyUs />
        <div className="section-divider" />
        <Testimonials />
        <div className="section-divider" />
        <FAQ />
        <div className="section-divider" />
        <Contact />
      </main>
      <Footer />
      <CookieConsent />
    </div>
  );
}
