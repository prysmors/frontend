export * from "../../data/content";
