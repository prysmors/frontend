import { motion } from "framer-motion";
import { Quote } from "lucide-react";
import Reveal from "../hooks/useReveal";
import { TESTIMONIALS, CLIENT_LOGOS } from "../../data/content";

export default function Testimonials() {
  return (
    <section id="testimonials" className="relative py-24 sm:py-32 overflow-hidden">
      {/* background glow */}
      <div
        className="pointer-events-none absolute -right-40 top-1/4 h-[500px] w-[500px] rounded-full opacity-10 blur-[120px]"
        style={{ background: "radial-gradient(circle, var(--color-violet) 0%, transparent 70%)" }}
        aria-hidden="true"
      />

      <div className="container-px relative z-10">
        <Reveal className="mb-16 text-center">
          <span className="mb-4 inline-block text-xs font-semibold uppercase tracking-widest text-[var(--color-mint)]">
            Client Stories
          </span>
          <h2 className="font-display text-4xl font-extrabold leading-[1.05] text-[var(--color-text)] sm:text-5xl">
            WHAT <span className="text-gradient">THEY SAY</span>
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-base leading-relaxed text-[var(--color-text-muted)]">
            Enterprise leaders across industries trust Prysmors as their intelligent decision layer.
          </p>
        </Reveal>

        {/* Testimonial cards */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {TESTIMONIALS.map((t, i) => (
            <Reveal key={t.name} delay={i * 0.1}>
              <motion.div
                whileHover={{ y: -6 }}
                transition={{ type: "spring", stiffness: 260, damping: 22 }}
                className="group relative flex h-full flex-col rounded-3xl border border-[var(--color-border)] bg-[var(--color-surface)]/80 p-7 backdrop-blur-sm transition-colors hover:border-[var(--color-mint)]/30"
              >
                {/* Quote icon */}
                <div className="mb-6 flex h-10 w-10 items-center justify-center rounded-xl bg-[var(--color-mint-deep)] text-[var(--color-mint)]">
                  <Quote size={18} />
                </div>

                {/* Stars */}
                <div className="mb-4 flex gap-1" aria-label="5 stars">
                  {Array.from({ length: 5 }).map((_, si) => (
                    <svg key={si} width="14" height="14" viewBox="0 0 24 24" fill="var(--color-mint)" aria-hidden="true">
                      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                    </svg>
                  ))}
                </div>

                <blockquote className="flex-1 text-sm leading-relaxed text-[var(--color-text-muted)]">
                  &ldquo;{t.quote}&rdquo;
                </blockquote>

                <div className="mt-7 flex items-center gap-3 border-t border-[var(--color-border-soft)] pt-5">
                  <img
                    src={t.avatar}
                    alt={t.name}
                    loading="lazy"
                    className="h-11 w-11 rounded-full object-cover ring-1 ring-[var(--color-border)]"
                    width={88}
                    height={88}
                  />
                  <div>
                    <p className="text-sm font-semibold text-[var(--color-text)]">{t.name}</p>
                    <p className="text-xs text-[var(--color-text-dim)]">
                      {t.role}, {t.company}
                    </p>
                  </div>
                </div>

                {/* hover accent line */}
                <div className="absolute bottom-0 left-6 right-6 h-[2px] rounded-full bg-gradient-to-r from-transparent via-[var(--color-mint)]/0 to-transparent transition-all duration-500 group-hover:via-[var(--color-mint)]/50" />
              </motion.div>
            </Reveal>
          ))}
        </div>

        {/* Trusted by logos */}
        <Reveal delay={0.15} className="mt-20">
          <p className="mb-8 text-center text-xs font-semibold uppercase tracking-widest text-[var(--color-text-dim)]">
            Trusted by enterprise teams across industries
          </p>
          <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-5">
            {CLIENT_LOGOS.map((logo) => (
              <div
                key={logo}
                className="rounded-xl border border-[var(--color-border-soft)] bg-[var(--color-surface)]/50 px-5 py-2.5 text-sm font-semibold text-[var(--color-text-dim)] transition-colors hover:border-[var(--color-border)] hover:text-[var(--color-text-muted)]"
              >
                {logo}
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
